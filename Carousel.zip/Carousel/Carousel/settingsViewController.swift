//
//  settingsViewController.swift
//  Carousel
//
//  Created by Lambdin, Daniel on 4/11/16.
//  Copyright © 2016 Daniel Lambdin. All rights reserved.
//

import UIKit

class settingsViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var signOutButton: UIButton!
    
    let alertController = UIAlertController(title: "Title", message: "Message", preferredStyle: .ActionSheet)


    let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel) { (action) in
        // handle case of user canceling. Doing nothing will dismiss the view.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let logoutAction = UIAlertAction(title: "Log Out", style: .Destructive) { (action) in
            // handle case of user logging out
            self.performSegueWithIdentifier("firstSegue", sender: self)
            
        }

        // Do any additional setup after loading the view.
        scrollView.contentSize = CGSize(width: 320, height: 886)
        
        // add the logout action to the alert controller
        alertController.addAction(logoutAction)
        
        // add the cancel action to the alert controller
        alertController.addAction(cancelAction)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    

    
    @IBAction func didPressClose(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func didPressSignOut(sender: AnyObject) {
        presentViewController(alertController, animated: true) {
            // optional code for what happens after the alert controller has finished presenting

        }
    }
    

}
