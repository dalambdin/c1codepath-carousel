//
//  LoginViewController.swift
//  Carousel
//
//  Created by Lambdin, Daniel on 4/8/16.
//  Copyright © 2016 Daniel Lambdin. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UIScrollViewDelegate {

    
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var buttonParentView: UIView!
    @IBOutlet weak var signInNavBar: UIImageView!
    @IBOutlet weak var fieldParentView: UIView!
    
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var signInIndicator: UIActivityIndicatorView!
    @IBOutlet weak var backButton: UIButton!
    

    let alertController = UIAlertController(title: "Sign In Failed", message: "Please enter the correct email address and password.", preferredStyle: .Alert)
    
    let emailAlertController = UIAlertController(title: "Sign In Failed", message: "Please enter an email address.", preferredStyle: .Alert)
    
    let passwordAlertController = UIAlertController(title: "Sign In Failed", message: "Please enter your password.", preferredStyle: .Alert)
    
    let blankAlertController = UIAlertController(title: "Sign In Failed", message: "Please enter an email address and password.", preferredStyle: .Alert)
    
    
    // create an OK action
    let OKAction = UIAlertAction(title: "OK", style: .Default) { (action) in
        // handle response here.
        
    }

    
    var buttonInitialY: CGFloat!
    var buttonOffset: CGFloat!
    

    override func viewDidLoad() {
       super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        
        scrollView.delegate = self
        
        scrollView.contentSize = scrollView.frame.size
        scrollView.contentInset.bottom = 100
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillShow(_:)), name:UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(keyboardWillHide(_:)), name:UIKeyboardWillHideNotification, object: nil)
        
        buttonInitialY = buttonParentView.frame.origin.y
        buttonOffset = -120
       
        alertController.addAction(OKAction)
        emailAlertController.addAction(OKAction)
        passwordAlertController.addAction(OKAction)
        blankAlertController.addAction(OKAction)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    // scrollView functions
    func scrollViewDidScroll(scrollView: UIScrollView) {
        // This method is called as the user scrolls

    }
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        
    }
    
    func scrollViewDidEndDragging(scrollView: UIScrollView,
                                  willDecelerate decelerate: Bool) {
        // This method is called right as the user lifts their finger
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        // This method is called when the scrollview finally stops scrolling.
        
    }

    //keyboard functions
    func keyboardWillShow(notification: NSNotification!) {
        print("keyboardWillShow")
        // Move the button up above keyboard
        buttonParentView.frame.origin.y = buttonInitialY + buttonOffset
        // Scroll the scrollview up
        scrollView.contentOffset.y = scrollView.contentInset.bottom
        
    }
    
    func keyboardWillHide(notification: NSNotification!) {
        // Move the buttons back down to it's original position
        buttonParentView.frame.origin.y = buttonInitialY
        
        
    }
    
    @IBAction func didTap(sender: AnyObject) {
        view.endEditing(true)

    }
    
    // Right before the ViewController "appears"...
    override func viewWillAppear(animated: Bool) {
        
        // Set initial transform values 20% of original size
        let transform = CGAffineTransformMakeScale(0.2, 0.2)
        // Apply the transform properties of the views
        signInNavBar.transform = transform
        fieldParentView.transform = transform
        // Set the alpha properties of the views to transparent
        signInNavBar.alpha = 0
        fieldParentView.alpha = 0

    }
    
    // The moment the ViewController "appears"...
    override func viewDidAppear(animated: Bool) {

        //Animate the code within over 0.3 seconds...
        UIView.animateWithDuration(0.3) { () -> Void in
            // Return the views transform properties to their default states.
            self.fieldParentView.transform = CGAffineTransformIdentity
            self.signInNavBar.transform = CGAffineTransformIdentity
            // Set the alpha properties of the views to fully opaque
            self.fieldParentView.alpha = 1
            self.signInNavBar.alpha = 1
        
        }
    }
    
    @IBAction func signInButtonDidTap(sender: AnyObject){
    
        
        signInIndicator.startAnimating()
        //signInButton.selected = true
        
        if emailField.text == "user" && passwordField.text == "pass" {
            // Code that runs if both email and password match the text we are looking for in each case
            delay(2) {
                self.signInIndicator.stopAnimating()
                self.performSegueWithIdentifier("firstSegue", sender: self)
            }
               
        }
        
        if emailField.text!.isEmpty && passwordField.text!.isEmpty {
            // Code that runs if both email and password match the text we are looking for in each case
            
            self.signInIndicator.stopAnimating()
            self.presentViewController(self.blankAlertController, animated: true) {
                // optional code for what happens after the alert controller has finished presenting
            }
            
        }
        
        if emailField.text!.isEmpty {
            // Code that runs if both email and password match the text we are looking for in each case
                self.signInIndicator.stopAnimating()
                self.presentViewController(self.emailAlertController, animated: true) {
                    // optional code for what happens after the alert controller has finished presenting
                    
                }
            
        }
            
        if passwordField.text!.isEmpty {
            // Code that runs if both email and password match the text we are looking for in each case
            
                self.signInIndicator.stopAnimating()
                self.presentViewController(self.passwordAlertController, animated: true) {
                    // optional code for what happens after the alert controller has finished presenting
                }

        }
                    
        else {
            // Code that runs if either the email or password do NOT match the text we are looking for in each case
            
            delay(2) {
                self.signInIndicator.stopAnimating()
          
            self.presentViewController(self.alertController, animated: true) {
                // optional code for what happens after the alert controller has finished presenting
                
            }
            
      }
                
            
        }
        
    }
    
    
    @IBAction func backDidTap(sender: AnyObject) {
        navigationController?.popToRootViewControllerAnimated(true)
        
    }
    
    
    func delay(delay:Double, closure:()->()) {
        dispatch_after(
            dispatch_time(
                DISPATCH_TIME_NOW,
                Int64(delay * Double(NSEC_PER_SEC))
            ),
            dispatch_get_main_queue(), closure)
    }
    
    
}
